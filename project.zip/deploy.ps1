# Deployment script for WebMiniDisc Pro to 10.1.1.200
$RemoteUser = "utking"
$RemoteHost = "10.1.1.200"
$ZipFile = "webminidisc.zip"

Write-Host "--- Transferring $ZipFile to $RemoteHost ---" -ForegroundColor Cyan
scp $ZipFile "${RemoteUser}@${RemoteHost}:/home/${RemoteUser}/"

if ($LASTEXITCODE -ne 0) {
    Write-Host "Transfer failed. Please check your password and connection." -ForegroundColor Red
    exit
}

Write-Host "--- Extracting and Starting Docker on $RemoteHost ---" -ForegroundColor Cyan
ssh "${RemoteUser}@${RemoteHost}" "mkdir -p webminidisc && unzip -o ../$ZipFile -d webminidisc && cd webminidisc && docker compose up -d"

if ($LASTEXITCODE -ne 0) {
    Write-Host "Remote execution failed." -ForegroundColor Red
} else {
    Write-Host "Done! App should be running at http://${RemoteHost}:8443" -ForegroundColor Green
}

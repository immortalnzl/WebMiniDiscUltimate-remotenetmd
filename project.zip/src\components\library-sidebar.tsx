import React, { useCallback, useEffect, useState } from 'react';
import { useShallowEqualSelector, useDispatch } from '../frontend-utils';
import { actions as localLibraryActions } from '../redux/local-library-feature';
import { openLocalLibrary } from '../redux/actions';
import serviceRegistry from '../services/registry';
import { File, FileBrowser } from './file-browser/browser';
import { FileType, dirSorter } from './file-browser/utils';
import { LocalDatabase } from '../services/library/library';
import { makeStyles } from 'tss-react/mui';
import { Typography, Box, InputBase, Paper, IconButton } from '@mui/material';
import { Search, Folder, Description, PlayArrow, Add } from '@mui/icons-material';
import { AdaptiveFile } from '../utils';
import { actions as convertDialogActions } from '../redux/convert-dialog-feature';

const useStyles = makeStyles()((theme) => ({
    root: {
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        borderRight: `1px solid ${theme.palette.divider}`,
        backgroundColor: theme.palette.background.default,
        overflow: 'hidden',
    },
    header: {
        padding: theme.spacing(2),
        display: 'flex',
        flexDirection: 'column',
        gap: theme.spacing(1),
    },
    search: {
        display: 'flex',
        alignItems: 'center',
        padding: '2px 4px',
        backgroundColor: theme.palette.background.paper,
        borderRadius: theme.shape.borderRadius,
    },
    input: {
        marginLeft: theme.spacing(1),
        flex: 1,
    },
    browserWrapper: {
        flexGrow: 1,
        overflow: 'auto',
    },
    playerMini: {
        padding: theme.spacing(1),
        borderTop: `1px solid ${theme.palette.divider}`,
        display: 'flex',
        alignItems: 'center',
        gap: theme.spacing(1),
    }
}));

export const MusicLibrarySidebar = ({ setUploadedFiles }: { setUploadedFiles: (files: AdaptiveFile[]) => void }) => {
    const { classes } = useStyles();
    const dispatch = useDispatch();
    const [currentPath, setCurrentPath] = useState<string[]>([]);
    const { database, status } = useShallowEqualSelector((state) => state.localLibrary);
    const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);

    const convertToFileArray = (data: LocalDatabase, path: string[] = []): File[] => {
        let currentData = data;
        const originalPath = [...path];
        const pathCopy = [...path];
        try {
            while(pathCopy.length){
                const part = pathCopy.shift();
                if (part && currentData[part]) {
                    currentData = currentData[part] as any;
                }
            }
        } catch (e) {
            return [];
        }
        
        return Object.entries(currentData).map(([key, value]) => {
            const isFolder = !('artist' in value);
            return {
                name: key,
                type: isFolder ? FileType.Directory : FileType.File,
                props: isFolder ? {} : {
                    ...value,
                    id: [...originalPath, key].join('/'),
                },
            };
        });
    };

    const [currentFileTree, setCurrentFileTree] = useState<File[]>([]);

    useEffect(() => {
        if (database) {
            setCurrentFileTree(convertToFileArray(database, currentPath));
        }
    }, [database, currentPath]);

    useEffect(() => {
        dispatch(openLocalLibrary());
    }, [dispatch]);

    const handleFileAction = useCallback((file: File) => {
        if (file.type === FileType.Directory) {
            setCurrentPath(e => [...e, file.name]);
        } else {
            // Play or Add? Let's use double click for add to playlist?
            // Actually, let's just use the actions.
        }
    }, []);

    const handleAddToPlaylist = useCallback((files: File[]) => {
        const process = (path: string[], files: File[]): File[] => {
            const finalFiles = [];
            for(let file of files){
                if(file.type === FileType.Directory) {
                    const newPath = [...path, file.name];
                    const subFiles = convertToFileArray(database ?? {}, newPath);
                    finalFiles.push(...process(newPath, subFiles));
                } else {
                    finalFiles.push(file);
                }
            }
            return finalFiles;
        };

        const tracksToAdd = process(currentPath, files);
        const adaptiveFiles: AdaptiveFile[] = tracksToAdd.map((file) => {
            const pathTokens = file.props!['id'].split('/');
            return {
                album: file.props!['album'],
                artist: file.props!['artist'],
                title: file.props!['title'],
                name: pathTokens[pathTokens.length - 1] || 'unknown.unk',
                duration: file.props!['duration'],
                artwork: file.props!['artwork'],
                getForEncoding: async (params) => {
                    return serviceRegistry.libraryService!.processLocalLibraryFile(file.props!['id'], params);
                },
            };
        });
        setUploadedFiles(adaptiveFiles);
        dispatch(convertDialogActions.setVisible(true));
    }, [database, currentPath, setUploadedFiles, dispatch]);

    return (
        <Box className={classes.root}>
            <Box className={classes.header}>
                <Typography variant="h6">BPI Music Library</Typography>
                <Paper className={classes.search}>
                    <Search color="disabled" sx={{ ml: 1 }} />
                    <InputBase
                        className={classes.input}
                        placeholder="Search music..."
                        inputProps={{ 'aria-label': 'search music' }}
                    />
                </Paper>
            </Box>
            <Box className={classes.browserWrapper}>
                <FileBrowser
                    fileTree={currentFileTree}
                    onFileDoubleClick={handleFileAction}
                    columnNotFoundPlaceholder=""
                    manualName={true}
                    allowMultifileSelection={true}
                    pathString={currentPath.join('/')}
                    iconGenerator={(file) => {
                        if (file.type === FileType.File && file.props?.artwork) {
                            return <img src={file.props.artwork} alt="" style={{ width: 24, height: 24, objectFit: 'cover' }} />;
                        }
                        return file.type === FileType.Directory ? <Folder /> : <Description />;
                    }}
                    additionalColumns={[
                        { name: 'name', sortable: true },
                    ]}
                    actions={[
                        {
                            name: 'Back',
                            actionPossible: () => currentPath.length > 0,
                            handler: () => setCurrentPath(e => e.slice(0, -1)),
                        },
                        {
                            name: 'Add to Disc',
                            icon: <Add />,
                            actionPossible: (e) => e.length > 0,
                            handler: (e) => handleAddToPlaylist(e),
                        },
                        {
                            name: 'Play',
                            icon: <PlayArrow />,
                            actionPossible: (e) => e.length === 1 && e[0].type === FileType.File,
                            handler: (e) => {
                                const url = serviceRegistry.libraryService?.getAudioUrl(e[0].props!['id']);
                                if (url) setCurrentAudioUrl(url);
                            },
                        }
                    ]}
                />
            </Box>
            {currentAudioUrl && (
                <Box className={classes.playerMini}>
                    <audio src={currentAudioUrl} controls autoPlay style={{ height: 32, flexGrow: 1 }} />
                    <IconButton size="small" onClick={() => setCurrentAudioUrl(null)}>
                        <Description fontSize="small" />
                    </IconButton>
                </Box>
            )}
        </Box>
    );
};

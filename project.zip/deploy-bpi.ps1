# WebMiniDisc Pro - BPI Deployment Script
$Server = "10.1.1.200"
$User = "utking"
$Pass = "Oxford18."
$RemoteDir = "webminidisc"
$ZipName = "webminidisc_deploy.zip"

Write-Host "--- 1. Pulling latest from Git (Local) ---" -ForegroundColor Cyan
# git pull --rebase  # Uncomment if you want to pull latest before deploying

Write-Host "--- 2. Zipping project files ---" -ForegroundColor Cyan
if (Test-Path $ZipName) { Remove-Item $ZipName }
Compress-Archive -Path "src", "backend", "public", "extra", "package.json", "package-lock.json", "Dockerfile", "docker-compose.yml", ".env", "index.html", "tsconfig.json", "tsconfig.node.json", "vite.config.ts", "README.md", "nginx.conf" -DestinationPath $ZipName

Write-Host "--- 3. Transferring to BPI ($Server) ---" -ForegroundColor Cyan
pscp -pw $Pass $ZipName "${User}@${Server}:/home/${User}/"

Write-Host "--- 4. Unzipping and Deploying on BPI ---" -ForegroundColor Cyan
$RemoteCmd = "unzip -o $ZipName -d $RemoteDir && cd $RemoteDir && export DOCKER_API_VERSION=1.53 && docker compose up -d --build"
plink -pw $Pass "${User}@${Server}" $RemoteCmd

if ($LASTEXITCODE -eq 0) {
    Write-Host "`nSuccessfully deployed! Access the app at http://${Server}:8443" -ForegroundColor Green
    Write-Host "Backend API is at http://${Server}:8000" -ForegroundColor Green
} else {
    Write-Host "`nDeployment failed. Check the logs above." -ForegroundColor Red
}

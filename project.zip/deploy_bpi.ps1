# WebMiniDisc Pro BPI Deployment Script
$BPI_IP = "10.1.1.200"
$BPI_USER = "utking"
$BPI_PW = "Oxford18."
$REMOTE_PATH = "webminidisc"

Write-Host "🚀 Syncing files to BPI..." -ForegroundColor Cyan
pscp -pw $BPI_PW -r . "${BPI_USER}@${BPI_IP}:${REMOTE_PATH}"

Write-Host "🏗️ Rebuilding and starting containers on BPI..." -ForegroundColor Cyan
plink -pw $BPI_PW "${BPI_USER}@${BPI_IP}" "export DOCKER_API_VERSION=1.44 && cd $REMOTE_PATH && docker compose up -d --build"

Write-Host "✅ Deployment Complete!" -ForegroundColor Green
